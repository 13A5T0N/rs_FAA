<?php
$server = "localhost";
$password = "";
$user = "root";
$db = "projecten";
$conn = mysqli_connect($server,$user,$password,$db);
?>